package br.edu.infnet.at_marianabs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtMarianaBsApplication {

    public static void main(String[] args) {
        SpringApplication.run(AtMarianaBsApplication.class, args);
    }

}
