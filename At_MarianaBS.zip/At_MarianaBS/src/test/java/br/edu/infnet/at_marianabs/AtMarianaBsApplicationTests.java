package br.edu.infnet.at_marianabs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtMarianaBsApplicationTests {

    @Test
    void contextLoads() {
    }

}
